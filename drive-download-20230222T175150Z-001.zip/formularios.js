//¿cómo seleccionar formularios?
/*
var formulario = document.getElementById("miFormulario");
var formulario2 = document.forms["miFormulario"];

var formulario3 = document.getElementsByTagName("form")[1];
var formulario4 = document.forms[1];

¿cómo seleccionar elementos?
 miFormulario.elements[]:devuelve un array con todos los datos del formulario
.getElementById("idElemento")//devuelve el elemento con ese id
.getElementsByTagName("etiqueta")// devuelve un array con el elemento que tenga en esa etiqueta(input,select...)
*/
window.onload = iniciar;
function iniciar() {
    document.getElementById("enviar").addEventListener('click', validar, false);
}
//al pulsar el botón enviar, invocará a la función validar()

function validaNombre() {
    var elemento = document.getElementById("nombre");
    limpiarError(elemento);
    if (elemento.value == "") {
        alert("El campo nombre no puede estar vacío");
        error(elemento);
        return false;
    }
    return true;
}

function validaTelefono() {
    var elemento = document.getElementById("telefono");
    if (isNaN(elemento.value)) {
        alert("El campo teléfono tiene que ser numérico");
        return false;
    }
    return true;
}

function validaFecha() {
    var dia = document.getElementById("dia").value;
    var mes = document.getElementById("mes").value;
    var anio = document.getElementById("anio").value;

    var fecha = new Date(anio, mes, dia);

    if (isNaN(fecha)) {
        alert("El campo fecha es incorrecto");
        return false;
    }
    return true;
}

function validaCheck() {
    var check = document.getElementById("mayor");
    if (!check.checked) {
        alert("Debe ser mayor de edad");
        return false;
    }
    return true;
}

function validaSexo() {
    var sexo = document.getElementsByName("sexo");
    for (let i = 0; i < sexo.length; i++) {
        if (sexo.checked) {
            return true;
        }
        return false;
    }
}

function validar(){
    if(validaNombre()&&validaFecha()&&validaTelefono()&&validaCheck()&&validaSexo()&&confirm("Pulsa aceptar para enviar el formulario")){
        return true;
    }
    return false;
}

function error(elemento){
    elemento.className="error";
    elemento.focus();
}

function limpiarError(elemento){
    elemento.className="";
}


